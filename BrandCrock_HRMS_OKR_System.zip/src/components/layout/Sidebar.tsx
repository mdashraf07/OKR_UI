import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Target,
  Kanban,
  CheckSquare,
  Award,
  Bell,
  Users,
  Building2,
  Calendar,
  FileCode2,
  GitFork,
  Calculator,
  ShieldAlert,
  Database,
  Inbox,
  FileCheck2,
} from 'lucide-react';
import { useAuthStore } from '../../features/auth/authStore';
import { getDb } from '../../api/mockDb';

export interface SidebarProps {
  isExpanded: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ isExpanded }) => {
  const { currentUser } = useAuthStore();
  const location = useLocation();
  const role = currentUser?.role || 'EMPLOYEE';

  const db = getDb();
  // Approvals count for badges
  const pendingApprovalsCount = db.approvalSteps.filter(
    (s) => s.status === 'PENDING' && (role === 'HR_ADMIN' ? s.stage === 2 : s.approverId === currentUser?.id)
  ).length;

  // Define nav links based on role (Section 9.3)
  interface NavItem {
    path: string;
    label: string;
    icon: React.ReactNode;
    badge?: number;
    section?: string;
  }

  let items: NavItem[] = [];

  if (role === 'EMPLOYEE') {
    items = [
      { path: '/dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
      { path: '/okrs', label: 'My OKRs', icon: <Target className="w-5 h-5" /> },
      { path: '/okrs/status', label: 'Status View', icon: <Kanban className="w-5 h-5" /> },
      { path: '/check-ins', label: 'Check-ins', icon: <CheckSquare className="w-5 h-5" /> },
      { path: '/reviews', label: 'My Reviews', icon: <Award className="w-5 h-5" /> },
      { path: '/notifications', label: 'Notifications', icon: <Bell className="w-5 h-5" /> },
    ];
  } else if (role === 'MANAGER') {
    items = [
      { path: '/dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
      {
        path: '/approvals',
        label: 'Approvals',
        icon: <Inbox className="w-5 h-5" />,
        badge: pendingApprovalsCount,
      },
      { path: '/team', label: 'Team OKRs', icon: <Users className="w-5 h-5" /> },
      { path: '/okrs', label: 'My OKRs', icon: <Target className="w-5 h-5" /> },
      { path: '/okrs/status', label: 'Status View', icon: <Kanban className="w-5 h-5" /> },
      { path: '/check-ins', label: 'Check-ins', icon: <CheckSquare className="w-5 h-5" /> },
      { path: '/reviews', label: 'Reviews', icon: <Award className="w-5 h-5" /> },
      { path: '/notifications', label: 'Notifications', icon: <Bell className="w-5 h-5" /> },
    ];
  } else {
    // HR_ADMIN
    items = [
      { path: '/dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
      {
        path: '/approvals',
        label: 'Approvals',
        icon: <Inbox className="w-5 h-5" />,
        badge: pendingApprovalsCount,
      },
      { path: '/company', label: 'Company OKRs', icon: <Building2 className="w-5 h-5" /> },
      { path: '/okrs', label: 'My OKRs', icon: <Target className="w-5 h-5" /> },
      { path: '/okrs/status', label: 'Status View', icon: <Kanban className="w-5 h-5" /> },
      { path: '/admin/cycles', label: 'Cycles', icon: <Calendar className="w-5 h-5" />, section: 'Administration' },
      { path: '/admin/templates', label: 'Templates', icon: <FileCode2 className="w-5 h-5" />, section: 'Administration' },
      { path: '/admin/workflows', label: 'Workflows', icon: <GitFork className="w-5 h-5" />, section: 'Administration' },
      { path: '/admin/scores', label: 'Scores', icon: <Calculator className="w-5 h-5" />, section: 'Administration' },
      { path: '/admin/reviews', label: 'Performance Reviews', icon: <FileCheck2 className="w-5 h-5" />, section: 'Administration' },
      { path: '/admin/master-data', label: 'Master Data', icon: <Database className="w-5 h-5" />, section: 'Administration' },
      { path: '/admin/audit-log', label: 'Audit Log', icon: <ShieldAlert className="w-5 h-5" />, section: 'Administration' },
      { path: '/notifications', label: 'Notifications', icon: <Bell className="w-5 h-5" /> },
    ];
  }

  return (
    <aside
      className={`fixed top-[60px] left-0 bottom-0 z-[40] transition-all duration-300 ease-in-out select-none flex flex-col ${
        isExpanded ? 'w-[240px]' : 'w-[80px]'
      }`}
      style={{
        backgroundColor: 'var(--color-sidebar-bg)',
      }}
    >
      <div className="flex-1 py-4 overflow-y-auto overflow-x-hidden space-y-1 px-2.5">
        {items.map((item, index) => {
          const isActive =
            location.pathname === item.path ||
            (item.path !== '/' && location.pathname.startsWith(item.path) && item.path !== '/okrs');

          const showSection =
            item.section &&
            (index === 0 || items[index - 1].section !== item.section);

          return (
            <React.Fragment key={item.path}>
              {showSection && isExpanded && (
                <div className="pt-3 pb-1 px-3 text-[10px] uppercase font-bold tracking-wider text-emerald-200/50">
                  {item.section}
                </div>
              )}
              {showSection && !isExpanded && (
                <div className="my-2 border-t border-emerald-900/40" />
              )}
              <NavLink
                to={item.path}
                title={!isExpanded ? item.label : undefined}
                className={`group flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 relative ${
                  isActive
                    ? 'text-white shadow-sm'
                    : 'text-[#a3cfc6] hover:text-white hover:bg-[#257e6f]/60'
                }`}
                style={{
                  backgroundColor: isActive ? 'var(--color-sidebar-active)' : undefined,
                }}
              >
                <div className="flex-shrink-0 flex items-center justify-center">
                  {item.icon}
                </div>

                {isExpanded && (
                  <span className="text-xs font-medium tracking-wide truncate">
                    {item.label}
                  </span>
                )}

                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`ml-auto px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                      isExpanded
                        ? 'bg-amber-400 text-slate-900'
                        : 'absolute top-1 right-2 w-4 h-4 flex items-center justify-center bg-amber-400 text-slate-900'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </NavLink>
            </React.Fragment>
          );
        })}
      </div>

      {/* Role Pill Indicator at bottom of sidebar */}
      <div className="p-3 border-t border-emerald-900/40 flex items-center justify-center bg-black/10">
        {isExpanded ? (
          <div className="flex flex-col text-center w-full">
            <span className="text-[10px] text-emerald-200/70 font-semibold uppercase">
              Current Role
            </span>
            <span className="text-xs font-bold text-white capitalize">
              {role === 'HR_ADMIN' ? 'HR / Admin' : role.toLowerCase()}
            </span>
          </div>
        ) : (
          <div
            title={`Active Role: ${role}`}
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold text-white uppercase"
          >
            {role[0]}
          </div>
        )}
      </div>
    </aside>
  );
};
