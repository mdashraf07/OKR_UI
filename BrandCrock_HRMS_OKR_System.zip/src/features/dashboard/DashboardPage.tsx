import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Target,
  AlertTriangle,
  Clock,
  Inbox,
  TrendingUp,
  ArrowRight,
  Filter,
} from 'lucide-react';
import { useAuthStore } from '../auth/authStore';
import { getObjectives, getApprovalSteps, getCheckIns } from '../../api';
import { getDb } from '../../api/mockDb';
import { Objective, KeyResult, ApprovalStep } from '../../types';
import { ProgressRing } from '../../components/ui/ProgressRing';
import { ProgressBar } from '../../components/ui/ProgressBar';
import {
  ObjectiveStatusPill,
  ObjectiveHealthChip,
  KRStatusChip,
  ApprovalChip,
} from '../../components/ui/Chips';
import { Button } from '../../components/ui/Button';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { calculateExpectedProgress } from '../../lib/calculations';

export const DashboardPage: React.FC = () => {
  const { currentUser, selectedCycleId } = useAuthStore();
  const navigate = useNavigate();
  const role = currentUser?.role || 'EMPLOYEE';

  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [approvals, setApprovals] = useState<ApprovalStep[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filters
  const [selectedDept, setSelectedDept] = useState<string>('ALL');

  const db = getDb();
  const currentCycle = db.cycles.find((c) => c.id === selectedCycleId) || db.cycles[1];
  const asOfDate = db.devSettings.demoDate;

  // Expected cycle progress
  const cycleExpectedPace = calculateExpectedProgress(
    currentCycle.startDate,
    currentCycle.endDate,
    asOfDate
  );

  const daysLeft = Math.max(
    0,
    Math.round(
      (new Date(currentCycle.endDate).getTime() - new Date(asOfDate).getTime()) /
        (1000 * 60 * 60 * 24)
    )
  );

  useEffect(() => {
    setIsLoading(true);
    Promise.all([
      getObjectives({
        cycleId: selectedCycleId,
        ownerId: role === 'EMPLOYEE' ? currentUser?.id : undefined,
      }),
      getApprovalSteps(role === 'MANAGER' ? currentUser?.id : undefined),
    ]).then(([objs, apprs]) => {
      setObjectives(objs);
      setApprovals(apprs);
      setIsLoading(false);
    });
  }, [selectedCycleId, currentUser, role]);

  // Key Results under these objectives
  const allKRs: KeyResult[] = db.keyResults.filter((kr) =>
    objectives.some((o) => o.id === kr.objectiveId)
  );

  // Filter by department if selected
  const filteredObjectives = objectives.filter((o) => {
    if (selectedDept !== 'ALL') {
      return o.departmentId?.toString() === selectedDept;
    }
    return true;
  });

  // Calculate overall progress average
  const activeObjs = filteredObjectives.filter((o) => o.status === 'Active');
  const overallProgress =
    activeObjs.length > 0
      ? Math.round(
          activeObjs.reduce((sum, o) => sum + (o.progress || 0), 0) / activeObjs.length
        )
      : 0;

  // At-risk and delayed KRs
  const atRiskOrDelayedKRs = allKRs.filter(
    (kr) => kr.status === 'At Risk' || kr.status === 'In Trouble' || kr.isDelayed
  );

  // Status distributions for Donut charts
  const objStatusData = [
    { name: 'Active', value: filteredObjectives.filter((o) => o.status === 'Active').length, color: '#16a34a' },
    { name: 'Draft', value: filteredObjectives.filter((o) => o.status === 'Draft').length, color: '#94a3b8' },
    { name: 'Completed', value: filteredObjectives.filter((o) => o.status === 'Completed').length, color: '#2563eb' },
    { name: 'Archived', value: filteredObjectives.filter((o) => o.status === 'Archived').length, color: '#475569' },
  ].filter((d) => d.value > 0);

  const krStatusData = [
    { name: 'On Track', value: allKRs.filter((k) => k.status === 'On Track').length, color: '#16a34a' },
    { name: 'At Risk', value: allKRs.filter((k) => k.status === 'At Risk').length, color: '#f59e0b' },
    { name: 'In Trouble', value: allKRs.filter((k) => k.status === 'In Trouble').length, color: '#ef4444' },
    { name: 'Completed', value: allKRs.filter((k) => k.status === 'Completed').length, color: '#2563eb' },
  ].filter((d) => d.value > 0);

  // Department Progress Bar Data
  const deptProgressData = db.departments.map((d) => {
    const deptObjs = objectives.filter((o) => o.departmentId === d.id && o.status === 'Active');
    const avg =
      deptObjs.length > 0
        ? Math.round(deptObjs.reduce((sum, o) => sum + (o.progress || 0), 0) / deptObjs.length)
        : 0;
    return { name: d.name, progress: avg };
  });

  return (
    <div className="space-y-6 pb-12">
      {/* 1. Cycle Hero Banner */}
      <div
        className="rounded-2xl p-6 text-white shadow-md relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, #1b675a 0%, #237a6b 60%, #298979 100%)',
        }}
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-white/20 text-white">
                {currentCycle.status} Cycle
              </span>
              <span className="text-xs text-emerald-100">
                {new Date(currentCycle.startDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} –{' '}
                {new Date(currentCycle.endDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
              </span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight">
              {role === 'EMPLOYEE' ? 'My Objectives & Performance' : `${currentCycle.name} Dashboard`}
            </h1>
            <p className="text-xs text-emerald-100/90 mt-1 max-w-xl">
              Cascading enterprise goals across departments, teams, and individuals with real-time governance.
            </p>
          </div>

          <div className="flex items-center gap-6 bg-white/10 backdrop-blur-sm px-5 py-3 rounded-2xl border border-white/20">
            <div className="text-center">
              <div className="text-2xl font-black">{daysLeft}</div>
              <div className="text-[10px] text-emerald-200 uppercase font-semibold">Days Left</div>
            </div>
            <div className="h-8 w-px bg-white/20" />
            <div className="text-center">
              <div className="text-2xl font-black">{cycleExpectedPace}%</div>
              <div className="text-[10px] text-emerald-200 uppercase font-semibold">Expected Pace</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-xs font-semibold text-slate-700">Filter View:</span>
          {role !== 'EMPLOYEE' && (
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="h-8 px-2.5 text-xs bg-slate-50 border border-slate-300 rounded-lg text-slate-700"
            >
              <option value="ALL">All Departments</option>
              {db.departments.map((d) => (
                <option key={d.id} value={d.id.toString()}>
                  {d.name}
                </option>
              ))}
            </select>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="secondary"
            onClick={() => navigate('/okrs/status')}
          >
            Open Status View
          </Button>
          <Button
            size="sm"
            variant="primary"
            onClick={() => navigate('/okrs/new')}
          >
            + Create Objective
          </Button>
        </div>
      </div>

      {/* 2. Row 1: KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Overall Progress Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
              Overall Progress
            </span>
            <div className="text-2xl font-bold text-slate-900">{overallProgress}%</div>
            <span className="text-[11px] text-slate-500 mt-1 block">
              Pace Target: {cycleExpectedPace}%
            </span>
          </div>
          <ProgressRing progress={overallProgress} expectedProgress={cycleExpectedPace} size={84} strokeWidth={8} />
        </div>

        {/* Objectives Count Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Objectives</span>
            <Target className="w-4 h-4 text-[#2d8fd8]" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900">{filteredObjectives.length}</div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
              <span className="text-emerald-600 font-semibold">{filteredObjectives.filter((o) => o.status === 'Active').length} Active</span>
              <span>·</span>
              <span className="text-slate-500">{filteredObjectives.filter((o) => o.status === 'Draft').length} Draft</span>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden flex">
            <div
              className="bg-emerald-500 h-full"
              style={{
                width: `${(filteredObjectives.filter((o) => o.status === 'Active').length / (filteredObjectives.length || 1)) * 100}%`,
              }}
            />
          </div>
        </div>

        {/* Key Results Count Card */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Key Results</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-slate-900">{allKRs.length}</div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
              <span className="text-emerald-600 font-semibold">{allKRs.filter((k) => k.status === 'On Track').length} On Track</span>
              <span>·</span>
              <span className="text-amber-600 font-semibold">{allKRs.filter((k) => k.status === 'At Risk').length} At Risk</span>
            </div>
          </div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden flex">
            <div
              className="bg-emerald-500 h-full"
              style={{
                width: `${(allKRs.filter((k) => k.status === 'On Track').length / (allKRs.length || 1)) * 100}%`,
              }}
            />
            <div
              className="bg-amber-500 h-full"
              style={{
                width: `${(allKRs.filter((k) => k.status === 'At Risk').length / (allKRs.length || 1)) * 100}%`,
              }}
            />
          </div>
        </div>

        {/* At-risk & Delayed Alert Card */}
        <div className="bg-white p-5 rounded-2xl border border-red-200 shadow-sm flex flex-col justify-between bg-red-50/20">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-red-700 uppercase tracking-wider">Attention Needed</span>
            <AlertTriangle className="w-4 h-4 text-red-500" />
          </div>
          <div className="my-2">
            <div className="text-2xl font-bold text-red-600">{atRiskOrDelayedKRs.length}</div>
            <div className="text-xs text-red-700 font-medium mt-1">
              KRs behind expected pace or delayed
            </div>
          </div>
          <button
            onClick={() => {
              const el = document.getElementById('at-risk-table');
              el?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="text-xs text-red-600 hover:underline font-semibold flex items-center gap-1"
          >
            View items <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* 3. Row 2: Objectives Overview & Status Distributions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Objectives Overview (2 columns) */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">Objectives Overview</h2>
              <p className="text-xs text-[#64748b]">Track current status, health pace, and progress</p>
            </div>
            <Button size="sm" variant="ghost" onClick={() => navigate('/okrs')}>
              View all ({filteredObjectives.length})
            </Button>
          </div>

          <div className="space-y-3">
            {filteredObjectives.slice(0, 5).map((obj) => (
              <div
                key={obj.id}
                onClick={() => navigate(`/okrs/${obj.id}`)}
                className="p-4 rounded-xl border border-slate-200/80 hover:border-[#2d8fd8] hover:shadow-sm cursor-pointer transition-all bg-slate-50/40 hover:bg-white"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                      {obj.level}
                    </span>
                    <h3 className="text-sm font-bold text-[#1e293b] hover:text-[#2d8fd8]">
                      {obj.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    <ObjectiveStatusPill status={obj.status} />
                    {obj.status === 'Active' && <ObjectiveHealthChip health={obj.health} />}
                    <ApprovalChip state={obj.approvalState} />
                  </div>
                </div>

                {/* Progress bar */}
                <div className="mt-3">
                  <ProgressBar
                    progress={obj.progress || 0}
                    expectedProgress={cycleExpectedPace}
                    showLabels
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Status Distribution Donut Charts */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between space-y-4">
          <div>
            <h2 className="text-base font-bold text-[#1e293b]">Status Distribution</h2>
            <p className="text-xs text-[#64748b]">Objective Lifecycle vs Key Result Status</p>
          </div>

          <div className="grid grid-cols-2 gap-2 text-center py-2">
            <div>
              <div className="text-xs font-semibold text-slate-600 mb-2">Objectives</div>
              <div className="h-32">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={objStatusData} dataKey="value" innerRadius={28} outerRadius={46} paddingAngle={4}>
                      {objStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div>
              <div className="text-xs font-semibold text-slate-600 mb-2">Key Results</div>
              <div className="h-32">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={krStatusData} dataKey="value" innerRadius={28} outerRadius={46} paddingAngle={4}>
                      {krStatusData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t text-xs space-y-1.5 text-slate-500">
            <div className="flex justify-between">
              <span>Active Objectives:</span>
              <span className="font-semibold text-slate-700">{filteredObjectives.filter((o) => o.status === 'Active').length}</span>
            </div>
            <div className="flex justify-between">
              <span>On Track KRs:</span>
              <span className="font-semibold text-emerald-600">{allKRs.filter((k) => k.status === 'On Track').length}</span>
            </div>
            <div className="flex justify-between">
              <span>At Risk / In Trouble KRs:</span>
              <span className="font-semibold text-red-600">{allKRs.filter((k) => k.status === 'At Risk' || k.status === 'In Trouble').length}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 4. Row 3: At-risk & Delayed KRs Table */}
      <div id="at-risk-table" className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <h2 className="text-base font-bold text-[#1e293b]">At-Risk and Delayed Key Results</h2>
          </div>
          <span className="text-xs text-slate-500">{atRiskOrDelayedKRs.length} requiring mitigation</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#f8f9fe] text-slate-700 font-semibold border-b">
                <th className="py-3 px-4 rounded-l-lg">Key Result</th>
                <th className="py-3 px-3">Owner</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Progress</th>
                <th className="py-3 px-3">Expected</th>
                <th className="py-3 px-3">Target Date</th>
                <th className="py-3 px-4 rounded-r-lg text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {atRiskOrDelayedKRs.map((kr) => {
                const owner = db.users.find((u) => u.id === kr.ownerId);
                return (
                  <tr key={kr.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-semibold text-slate-800">
                      {kr.name}
                    </td>
                    <td className="py-3 px-3 text-slate-600">{owner?.name || 'Owner'}</td>
                    <td className="py-3 px-3">
                      <KRStatusChip
                        status={kr.status}
                        isDelayed={kr.isDelayed}
                        isOverridden={kr.statusOverridden}
                      />
                    </td>
                    <td className="py-3 px-3 font-semibold">{kr.achievementPercent}%</td>
                    <td className="py-3 px-3 text-slate-500">{kr.expectedPercent}%</td>
                    <td className="py-3 px-3 text-slate-500">
                      {new Date(kr.targetDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => navigate(`/okrs/${kr.objectiveId}/krs/${kr.id}`)}
                      >
                        Details
                      </Button>
                    </td>
                  </tr>
                );
              })}
              {atRiskOrDelayedKRs.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center py-6 text-slate-400">
                    All key results are currently on track.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
