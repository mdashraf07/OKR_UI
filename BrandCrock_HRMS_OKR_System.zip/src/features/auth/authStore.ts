import { create } from 'zustand';
import { User, Role } from '../../types';
import { SEED_USERS } from '../../api/seedData';

interface AuthState {
  currentUser: User | null;
  user: User | null;
  selectedCycleId: number;
  idleTimerLastActive: number;
  sessionTimeoutWarning: boolean;
  login: (userIdOrEmail: number | string) => boolean;
  logout: () => void;
  setSelectedCycleId: (cycleId: number) => void;
  touchActivity: () => void;
  dismissTimeoutWarning: () => void;
}

const SESSION_KEY = 'okr_auth_session_user_id';
const CYCLE_KEY = 'okr_auth_selected_cycle_id';

function getInitialUser(): User | null {
  try {
    const saved = localStorage.getItem(SESSION_KEY);
    if (saved) {
      const id = parseInt(saved, 10);
      const user = SEED_USERS.find((u) => u.id === id);
      if (user && user.active) return user;
    }
  } catch (e) {
    console.warn('Session parse error:', e);
  }
  // Default to Ashraf (Employee) for rich immediate demo experience
  return SEED_USERS[0];
}

function getInitialCycleId(): number {
  try {
    const saved = localStorage.getItem(CYCLE_KEY);
    if (saved) {
      return parseInt(saved, 10);
    }
  } catch (e) {
    // fallback
  }
  return 2; // Active Q4 2026 cycle
}

const initialUser = getInitialUser();

export const useAuthStore = create<AuthState>((set) => ({
  currentUser: initialUser,
  user: initialUser,
  selectedCycleId: getInitialCycleId(),
  idleTimerLastActive: Date.now(),
  sessionTimeoutWarning: false,

  login: (userIdOrEmail: number | string) => {
    let found: User | undefined;
    if (typeof userIdOrEmail === 'number') {
      found = SEED_USERS.find((u) => u.id === userIdOrEmail);
    } else {
      found = SEED_USERS.find(
        (u) =>
          u.email.toLowerCase() === userIdOrEmail.toLowerCase() ||
          u.employeeCode?.toLowerCase() === userIdOrEmail.toLowerCase()
      );
    }

    if (!found || !found.active) {
      return false;
    }

    localStorage.setItem(SESSION_KEY, found.id.toString());
    set({
      currentUser: found,
      user: found,
      idleTimerLastActive: Date.now(),
      sessionTimeoutWarning: false,
    });
    return true;
  },

  logout: () => {
    localStorage.removeItem(SESSION_KEY);
    set({ currentUser: null, user: null, sessionTimeoutWarning: false });
  },

  setSelectedCycleId: (cycleId: number) => {
    localStorage.setItem(CYCLE_KEY, cycleId.toString());
    set({ selectedCycleId: cycleId });
  },

  touchActivity: () => {
    set({ idleTimerLastActive: Date.now() });
  },

  dismissTimeoutWarning: () => {
    set({ sessionTimeoutWarning: false, idleTimerLastActive: Date.now() });
  },
}));

export function isAllowed(user: User | null, requiredRole: Role): boolean {
  if (!user) return false;
  if (user.role === 'HR_ADMIN') return true; // HR_ADMIN has access to all roles
  if (user.role === 'MANAGER' && requiredRole !== 'HR_ADMIN') return true;
  return user.role === requiredRole;
}
