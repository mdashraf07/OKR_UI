import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, ShieldCheck, UserCheck, ArrowRight } from 'lucide-react';
import { useAuthStore } from './authStore';
import { SEED_USERS } from '../../api/seedData';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { useToastStore } from '../../components/ui/Toast';

export const LoginPage: React.FC = () => {
  const [identifier, setIdentifier] = useState('ashraf@company.com');
  const [password, setPassword] = useState('password123');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const { login } = useAuthStore();
  const { showToast } = useToastStore();
  const navigate = useNavigate();

  const handleSignIn = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);
    setIsLoading(true);

    setTimeout(() => {
      const success = login(identifier);
      setIsLoading(false);
      if (success) {
        showToast({ type: 'success', message: 'Signed in successfully' });
        navigate('/dashboard');
      } else {
        setError('Email or password is incorrect.');
      }
    }, 400);
  };

  const selectDemoAccount = (userId: number) => {
    const user = SEED_USERS.find((u) => u.id === userId);
    if (user) {
      setIdentifier(user.email);
      setPassword('password123');
      setIsLoading(true);
      setTimeout(() => {
        login(user.id);
        setIsLoading(false);
        showToast({ type: 'success', message: `Signed in as ${user.name} (${user.role})` });
        navigate('/dashboard');
      }, 300);
    }
  };

  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-center p-4 relative"
      style={{
        background: 'linear-gradient(135deg, #1b675a 0%, #237a6b 50%, #1a7260 100%)',
      }}
    >
      {/* Background Decorative Rings */}
      <div className="absolute top-10 left-10 w-96 h-96 rounded-full bg-white/5 pointer-events-none blur-2xl" />
      <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-emerald-400/10 pointer-events-none blur-3xl" />

      {/* Main Login Card */}
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-white/20 p-8 z-10 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-[#1b675a] text-white font-bold text-lg shadow-md mb-3">
            LOGO
          </div>
          <h1 className="text-xl font-bold text-[#1e293b] tracking-tight">
            OKR & Performance Management
          </h1>
          <p className="text-xs text-[#64748b] mt-1">
            Enterprise Objectives, Key Results Cascade & Governance
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="mb-5 p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 font-medium">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSignIn} className="space-y-4">
          <Input
            label="Email or Employee ID"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
            placeholder="e.g. ashraf@company.com or EMP-1001"
            required
          />

          <div className="relative">
            <Input
              label="Password"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
              rightIcon={
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-slate-400 hover:text-slate-600 focus:outline-none"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              }
            />
          </div>

          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 text-[#64748b] cursor-pointer">
              <input type="checkbox" defaultChecked className="rounded text-[#2d8fd8]" />
              <span>Remember me</span>
            </label>
            <button
              type="button"
              onClick={() => showToast({ type: 'info', message: 'Not available in the demo.' })}
              className="text-[#2d8fd8] hover:underline font-medium"
            >
              Forgot password?
            </button>
          </div>

          <Button
            type="submit"
            variant="primary"
            isLoading={isLoading}
            className="w-full mt-2 h-11 text-sm font-semibold rounded-xl"
            rightIcon={<ArrowRight className="w-4 h-4" />}
          >
            Sign in
          </Button>
        </form>

        {/* Quick Demo Accounts Selection */}
        <div className="mt-8 pt-6 border-t border-slate-100">
          <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider text-center mb-3 flex items-center justify-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Select Demo Account</span>
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            {/* Ashraf (Employee) */}
            <div
              onClick={() => selectDemoAccount(1)}
              className="p-3 rounded-xl border border-slate-200 hover:border-[#2d8fd8] bg-slate-50/60 hover:bg-sky-50/50 cursor-pointer transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 font-bold text-xs flex items-center justify-center">
                  AS
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#1e293b] group-hover:text-[#2d8fd8]">
                    Ashraf <span className="font-normal text-slate-500">(Employee)</span>
                  </div>
                  <div className="text-[10px] text-slate-500">Sales Executive · Set goals & track</div>
                </div>
              </div>
              <UserCheck className="w-4 h-4 text-slate-300 group-hover:text-[#2d8fd8]" />
            </div>

            {/* Ravi Menon (Manager) */}
            <div
              onClick={() => selectDemoAccount(2)}
              className="p-3 rounded-xl border border-slate-200 hover:border-[#2d8fd8] bg-slate-50/60 hover:bg-sky-50/50 cursor-pointer transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 font-bold text-xs flex items-center justify-center">
                  RM
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#1e293b] group-hover:text-[#2d8fd8]">
                    Ravi Menon <span className="font-normal text-slate-500">(Manager)</span>
                  </div>
                  <div className="text-[10px] text-slate-500">Sales Team Lead · Level 1 Approvals</div>
                </div>
              </div>
              <UserCheck className="w-4 h-4 text-slate-300 group-hover:text-[#2d8fd8]" />
            </div>

            {/* Priya Nair (HR/Admin) */}
            <div
              onClick={() => selectDemoAccount(3)}
              className="p-3 rounded-xl border border-slate-200 hover:border-[#2d8fd8] bg-slate-50/60 hover:bg-sky-50/50 cursor-pointer transition-all flex items-center justify-between group"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 font-bold text-xs flex items-center justify-center">
                  PN
                </div>
                <div>
                  <div className="text-xs font-semibold text-[#1e293b] group-hover:text-[#2d8fd8]">
                    Priya Nair <span className="font-normal text-slate-500">(HR/Admin)</span>
                  </div>
                  <div className="text-[10px] text-slate-500">HR Manager · Level 2 & Admin Controls</div>
                </div>
              </div>
              <UserCheck className="w-4 h-4 text-slate-300 group-hover:text-[#2d8fd8]" />
            </div>
          </div>
        </div>

        <div className="mt-6 text-center text-[11px] text-slate-400">
          Demo prototype. Data is kept locally in browser storage.
        </div>
      </div>
    </div>
  );
};
