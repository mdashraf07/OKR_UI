import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2, Plus, Link as LinkIcon, Network, CheckCircle2 } from 'lucide-react';
import { useAuthStore } from '../auth/authStore';
import { getDb } from '../../api/mockDb';
import { Button } from '../../components/ui/Button';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { calculateExpectedProgress } from '../../lib/calculations';
import { ObjectiveStatusPill, ObjectiveHealthChip } from '../../components/ui/Chips';

export const CompanyOkrsPage: React.FC = () => {
  const { selectedCycleId } = useAuthStore();
  const navigate = useNavigate();

  const db = getDb();
  const currentCycle = db.cycles.find((c) => c.id === selectedCycleId) || db.cycles[1];
  const asOfDate = db.devSettings.demoDate;
  const cycleExpectedPace = calculateExpectedProgress(currentCycle.startDate, currentCycle.endDate, asOfDate);

  const orgObjectives = db.objectives.filter(
    (o) => o.cycleId === selectedCycleId && o.level === 'Organization'
  );

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1e293b]">Company-Wide Strategic OKRs</h1>
          <p className="text-xs text-[#64748b] mt-1">
            Enterprise alignment tree cascading from company vision to departmental teams.
          </p>
        </div>

        <Button
          variant="primary"
          onClick={() => navigate('/okrs/new')}
          leftIcon={<Plus className="w-4 h-4" />}
        >
          Create Strategic Goal
        </Button>
      </div>

      {/* Alignment Tree Cascade View */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
        <div className="space-y-6">
          {orgObjectives.map((org) => {
            const deptObjs = db.objectives.filter(
              (o) => o.parentObjectiveId === org.id && o.cycleId === selectedCycleId
            );

            return (
              <div key={org.id} className="border-2 border-emerald-300 rounded-2xl p-5 bg-emerald-50/20 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-600 text-white font-bold text-xs">
                      Organization
                    </span>
                    <h2
                      onClick={() => navigate(`/okrs/${org.id}`)}
                      className="text-base font-bold text-slate-900 hover:text-[#2d8fd8] cursor-pointer"
                    >
                      {org.title}
                    </h2>
                  </div>
                  <ProgressBar
                    progress={org.progress || 0}
                    expectedProgress={cycleExpectedPace}
                    showLabels
                    className="w-48"
                  />
                </div>

                {/* Departments under this org goal */}
                <div className="pl-6 border-l-2 border-emerald-400 space-y-4">
                  {deptObjs.map((dept) => {
                    const teamObjs = db.objectives.filter(
                      (o) => o.parentObjectiveId === dept.id && o.cycleId === selectedCycleId
                    );

                    return (
                      <div key={dept.id} className="border border-sky-300 rounded-xl p-4 bg-sky-50/20 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="px-2 py-0.5 rounded bg-[#2d8fd8] text-white font-bold text-xs">
                              Department
                            </span>
                            <h3
                              onClick={() => navigate(`/okrs/${dept.id}`)}
                              className="text-sm font-bold text-slate-900 hover:text-[#2d8fd8] cursor-pointer"
                            >
                              {dept.title}
                            </h3>
                          </div>
                          <ProgressBar
                            progress={dept.progress || 0}
                            expectedProgress={cycleExpectedPace}
                            showLabels
                            className="w-44"
                          />
                        </div>

                        {/* Teams under department */}
                        <div className="pl-6 border-l-2 border-sky-400 space-y-2">
                          {teamObjs.map((team) => (
                            <div
                              key={team.id}
                              onClick={() => navigate(`/okrs/${team.id}`)}
                              className="p-3 bg-white rounded-lg border border-slate-200 hover:border-[#2d8fd8] cursor-pointer flex items-center justify-between text-xs"
                            >
                              <div className="flex items-center gap-2">
                                <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-bold text-[10px]">
                                  Team
                                </span>
                                <span className="font-semibold text-slate-800">{team.title}</span>
                              </div>
                              <ProgressBar
                                progress={team.progress || 0}
                                expectedProgress={cycleExpectedPace}
                                showLabels
                                className="w-36"
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
