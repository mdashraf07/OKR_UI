import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Search,
  Plus,
  Table as TableIcon,
  LayoutGrid,
  Network,
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';
import { useAuthStore } from '../auth/authStore';
import { getObjectives, cancelObjective } from '../../api';
import { getDb } from '../../api/mockDb';
import { Objective, KeyResult, ObjectiveLevel, ObjectiveLifecycleStatus, ApprovalState } from '../../types';
import {
  ObjectiveStatusPill,
  ObjectiveHealthChip,
  KRStatusChip,
  ApprovalChip,
} from '../../components/ui/Chips';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { TableSkeleton } from '../../components/ui/Skeleton';
import { useToastStore } from '../../components/ui/Toast';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { calculateExpectedProgress, formatValueWithUnit } from '../../lib/calculations';

export const OkrListPage: React.FC = () => {
  const { currentUser, selectedCycleId } = useAuthStore();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { showToast } = useToastStore();

  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'table' | 'cards' | 'hierarchy'>('table');
  const [expandedRows, setExpandedRows] = useState<Record<number, boolean>>({});

  // Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [levelFilter, setLevelFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [approvalFilter, setApprovalFilter] = useState<string>('ALL');

  // Cancel dialog state
  const [cancelTargetId, setCancelTargetId] = useState<number | null>(null);

  const db = getDb();
  const currentCycle = db.cycles.find((c) => c.id === selectedCycleId) || db.cycles[1];
  const asOfDate = db.devSettings.demoDate;
  const cycleExpectedPace = calculateExpectedProgress(currentCycle.startDate, currentCycle.endDate, asOfDate);

  const fetchObjectives = () => {
    setIsLoading(true);
    const ownerParam = searchParams.get('ownerId');
    const ownerId = ownerParam
      ? Number(ownerParam)
      : currentUser?.role === 'EMPLOYEE'
      ? currentUser.id
      : undefined;

    getObjectives({
      cycleId: selectedCycleId,
      ownerId,
    }).then((data) => {
      setObjectives(data);
      setIsLoading(false);
    });
  };

  useEffect(() => {
    fetchObjectives();
  }, [selectedCycleId, currentUser, searchParams]);

  const toggleRow = (id: number) => {
    setExpandedRows((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Filtered objectives
  const filtered = objectives.filter((o) => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = o.title.toLowerCase().includes(q);
      const matchDesc = o.description?.toLowerCase().includes(q);
      if (!matchTitle && !matchDesc) return false;
    }
    if (levelFilter !== 'ALL' && o.level !== levelFilter) return false;
    if (statusFilter !== 'ALL' && o.status !== statusFilter) return false;
    if (approvalFilter !== 'ALL' && o.approvalState !== approvalFilter) return false;
    return true;
  });

  // Calculate my objective weightages total in cycle
  const myObjectives = objectives.filter((o) => o.ownerId === currentUser?.id);
  const myTotalWeightage = myObjectives.reduce((sum, o) => sum + (o.weightage || 0), 0);

  const handleCancelConfirm = async () => {
    if (!cancelTargetId) return;
    try {
      await cancelObjective(cancelTargetId, 'Cancelled from list view', currentUser?.id || 1);
      showToast({ type: 'success', message: 'Objective archived/cancelled' });
      setCancelTargetId(null);
      fetchObjectives();
    } catch (err: any) {
      showToast({ type: 'error', message: err.message || 'Failed to cancel' });
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header & View Switcher */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {currentCycle.name}
            </span>
            <span className="text-slate-300">·</span>
            <span className="text-xs text-slate-500">
              Pace Today: {cycleExpectedPace}%
            </span>
          </div>
          <h1 className="text-2xl font-bold text-[#1e293b]">Objectives & Key Results</h1>
          <p className="text-xs text-[#64748b] mt-1">
            View goal cascades, track progress against expected pace, and drill into key results.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* View Toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                viewMode === 'table' ? 'bg-white shadow text-[#2d8fd8]' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Table</span>
            </button>
            <button
              onClick={() => setViewMode('cards')}
              className={`p-1.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                viewMode === 'cards' ? 'bg-white shadow text-[#2d8fd8]' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" />
              <span>Cards</span>
            </button>
            <button
              onClick={() => setViewMode('hierarchy')}
              className={`p-1.5 px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                viewMode === 'hierarchy' ? 'bg-white shadow text-[#2d8fd8]' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Network className="w-3.5 h-3.5" />
              <span>Hierarchy</span>
            </button>
          </div>

          <Button
            variant="primary"
            onClick={() => navigate('/okrs/new')}
            leftIcon={<Plus className="w-4 h-4" />}
          >
            Create Objective
          </Button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-wrap items-center gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search objectives and descriptions..."
            className="w-full h-9 pl-9 pr-3 text-xs rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#2d8fd8]"
          />
        </div>

        {/* Level filter */}
        <select
          value={levelFilter}
          onChange={(e) => setLevelFilter(e.target.value)}
          className="h-9 px-3 text-xs rounded-lg border border-slate-200 bg-slate-50 text-slate-700 focus:outline-none"
        >
          <option value="ALL">All Levels</option>
          <option value="Organization">Organization</option>
          <option value="Department">Department</option>
          <option value="Team">Team</option>
          <option value="Individual">Individual</option>
        </select>

        {/* Status filter */}
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="h-9 px-3 text-xs rounded-lg border border-slate-200 bg-slate-50 text-slate-700 focus:outline-none"
        >
          <option value="ALL">All Statuses</option>
          <option value="Active">Active</option>
          <option value="Draft">Draft</option>
          <option value="Completed">Completed</option>
          <option value="Archived">Archived</option>
        </select>

        {/* Approval filter */}
        <select
          value={approvalFilter}
          onChange={(e) => setApprovalFilter(e.target.value)}
          className="h-9 px-3 text-xs rounded-lg border border-slate-200 bg-slate-50 text-slate-700 focus:outline-none"
        >
          <option value="ALL">All Approvals</option>
          <option value="NotSubmitted">Not Submitted</option>
          <option value="PendingManager">Pending Manager</option>
          <option value="PendingHR">Pending HR/Admin</option>
          <option value="Approved">Approved</option>
          <option value="Returned">Returned</option>
          <option value="Rejected">Rejected</option>
        </select>

        {(searchQuery || levelFilter !== 'ALL' || statusFilter !== 'ALL' || approvalFilter !== 'ALL') && (
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setSearchQuery('');
              setLevelFilter('ALL');
              setStatusFilter('ALL');
              setApprovalFilter('ALL');
            }}
          >
            Clear filters
          </Button>
        )}
      </div>

      {/* Loading Skeleton */}
      {isLoading ? (
        <TableSkeleton rows={6} />
      ) : filtered.length === 0 ? (
        <EmptyState
          title={searchQuery || levelFilter !== 'ALL' ? 'No objectives match your filters' : 'No objectives yet'}
          description={
            searchQuery || levelFilter !== 'ALL'
              ? 'Try modifying your filter selections or clearing the search query.'
              : 'Create your first objective for this cycle or start from a pre-approved template.'
          }
          action={
            <div className="flex gap-2">
              <Button size="sm" variant="primary" onClick={() => navigate('/okrs/new')}>
                Create objective
              </Button>
              <Button size="sm" variant="secondary" onClick={() => navigate('/okrs/new?template=true')}>
                Start from template
              </Button>
            </div>
          }
        />
      ) : (
        <>
          {/* 1. TABLE VIEW */}
          {viewMode === 'table' && (
            <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#f8f9fe] text-slate-700 font-semibold border-b border-slate-200/70">
                      <th className="py-3 px-4 w-10"></th>
                      <th className="py-3 px-3">Objective</th>
                      <th className="py-3 px-3">Level</th>
                      <th className="py-3 px-3">Owner</th>
                      <th className="py-3 px-3">Objective Status</th>
                      <th className="py-3 px-3">Health</th>
                      <th className="py-3 px-3">Approval</th>
                      <th className="py-3 px-4 w-44">Progress</th>
                      <th className="py-3 px-3 text-center">Weightage</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filtered.map((obj) => {
                      const isExpanded = !!expandedRows[obj.id];
                      const krs = db.keyResults.filter((k) => k.objectiveId === obj.id);
                      const owner = db.users.find((u) => u.id === obj.ownerId);

                      return (
                        <React.Fragment key={obj.id}>
                          {/* Parent Objective Row */}
                          <tr
                            onClick={() => toggleRow(obj.id)}
                            className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                          >
                            <td className="py-3 px-4 text-center">
                              {krs.length > 0 ? (
                                <button className="p-1 rounded hover:bg-slate-200 text-slate-400 group-hover:text-slate-700">
                                  {isExpanded ? (
                                    <ChevronDown className="w-4 h-4" />
                                  ) : (
                                    <ChevronRight className="w-4 h-4" />
                                  )}
                                </button>
                              ) : null}
                            </td>
                            <td className="py-3 px-3 font-semibold text-slate-900 group-hover:text-[#2d8fd8]">
                              <div className="truncate max-w-md">{obj.title}</div>
                              {obj.description && (
                                <div className="text-[11px] text-slate-500 font-normal truncate max-w-sm mt-0.5">
                                  {obj.description}
                                </div>
                              )}
                            </td>
                            <td className="py-3 px-3">
                              <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-medium">
                                {obj.level}
                              </span>
                            </td>
                            <td className="py-3 px-3 text-slate-700">{owner?.name || 'Owner'}</td>
                            <td className="py-3 px-3">
                              <ObjectiveStatusPill status={obj.status} />
                            </td>
                            <td className="py-3 px-3">
                              <ObjectiveHealthChip health={obj.health} />
                            </td>
                            <td className="py-3 px-3">
                              <ApprovalChip state={obj.approvalState} />
                            </td>
                            <td className="py-3 px-4">
                              <ProgressBar
                                progress={obj.progress || 0}
                                expectedProgress={cycleExpectedPace}
                                showLabels
                              />
                            </td>
                            <td className="py-3 px-3 text-center font-semibold text-slate-700">
                              {obj.weightage}%
                            </td>
                            <td className="py-3 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                              <div className="flex justify-end gap-1">
                                <Button
                                  size="sm"
                                  variant="secondary"
                                  onClick={() => navigate(`/okrs/${obj.id}`)}
                                >
                                  Details
                                </Button>
                              </div>
                            </td>
                          </tr>

                          {/* Inline Expanded Key Results */}
                          {isExpanded && (
                            <tr className="bg-slate-50/70 border-b">
                              <td colSpan={10} className="p-4 pl-14">
                                <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-inner">
                                  <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center justify-between">
                                    <span>Key Results under this objective ({krs.length})</span>
                                    <button
                                      onClick={() => navigate(`/okrs/${obj.id}/krs/new`)}
                                      className="text-[#2d8fd8] hover:underline normal-case font-medium"
                                    >
                                      + Add Key Result
                                    </button>
                                  </div>

                                  <table className="w-full text-xs text-left">
                                    <thead>
                                      <tr className="text-slate-500 border-b border-slate-100">
                                        <th className="py-2 px-3">Key Result</th>
                                        <th className="py-2 px-3">Current / Target</th>
                                        <th className="py-2 px-3">KR Status</th>
                                        <th className="py-2 px-3 w-40">Progress</th>
                                        <th className="py-2 px-3 text-center">Weight</th>
                                        <th className="py-2 px-3 text-right">Action</th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                      {krs.map((kr) => (
                                        <tr key={kr.id} className="hover:bg-slate-50">
                                          <td className="py-2.5 px-3 font-medium text-slate-800">
                                            {kr.name}
                                          </td>
                                          <td className="py-2.5 px-3 text-slate-600 font-mono">
                                            {kr.current} / {kr.target}
                                          </td>
                                          <td className="py-2.5 px-3">
                                            <KRStatusChip
                                              status={kr.status}
                                              isDelayed={kr.isDelayed}
                                              isOverridden={kr.statusOverridden}
                                            />
                                          </td>
                                          <td className="py-2.5 px-3">
                                            <ProgressBar
                                              progress={kr.achievementPercent}
                                              expectedProgress={kr.expectedPercent}
                                              showLabels
                                            />
                                          </td>
                                          <td className="py-2.5 px-3 text-center text-slate-600">
                                            {kr.weightage}%
                                          </td>
                                          <td className="py-2.5 px-3 text-right">
                                            <button
                                              onClick={() =>
                                                navigate(`/okrs/${obj.id}/krs/${kr.id}/update`)
                                              }
                                              className="text-[#2d8fd8] hover:underline font-semibold"
                                            >
                                              Update
                                            </button>
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </td>
                            </tr>
                          )}
                        </React.Fragment>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* List Footer with Objective Weightages warning */}
              <div className="p-4 bg-slate-50 border-t border-slate-200/80 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-600 gap-2">
                <div>
                  Showing <span className="font-bold">{filtered.length}</span> objectives
                </div>
                <div className="flex items-center gap-2">
                  <span>Your total objective weightage in this cycle:</span>
                  <span
                    className={`font-bold px-2 py-0.5 rounded-full ${
                      myTotalWeightage === 100
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {myTotalWeightage} of 100
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 2. CARDS VIEW */}
          {viewMode === 'cards' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filtered.map((obj) => {
                const krs = db.keyResults.filter((k) => k.objectiveId === obj.id);
                const owner = db.users.find((u) => u.id === obj.ownerId);

                return (
                  <div
                    key={obj.id}
                    onClick={() => navigate(`/okrs/${obj.id}`)}
                    className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm hover:border-[#2d8fd8] hover:shadow-md cursor-pointer transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                          {obj.level}
                        </span>
                        <div className="flex gap-1.5">
                          <ObjectiveStatusPill status={obj.status} />
                          <ObjectiveHealthChip health={obj.health} />
                        </div>
                      </div>

                      <h3 className="font-bold text-sm text-[#1e293b] mb-1">{obj.title}</h3>
                      {obj.description && (
                        <p className="text-xs text-[#64748b] line-clamp-2 mb-3">
                          {obj.description}
                        </p>
                      )}

                      <div className="flex items-center justify-between text-xs text-slate-500 mb-3">
                        <span>Owner: {owner?.name}</span>
                        <ApprovalChip state={obj.approvalState} />
                      </div>
                    </div>

                    <div className="pt-3 border-t border-slate-100">
                      <ProgressBar
                        progress={obj.progress || 0}
                        expectedProgress={cycleExpectedPace}
                        showLabels
                      />
                      <div className="flex justify-between items-center text-[11px] text-slate-500 mt-2">
                        <span>{krs.length} Key Results</span>
                        <span>Weight: {obj.weightage}%</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* 3. HIERARCHY ALIGNMENT TREE VIEW */}
          {viewMode === 'hierarchy' && (
            <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
              <div className="border-b pb-3">
                <h2 className="text-base font-bold text-[#1e293b]">Goal Alignment Cascade</h2>
                <p className="text-xs text-[#64748b]">
                  Visual hierarchy from Organization to Department, Team, and Individual objectives.
                </p>
              </div>

              {/* Cascade Root Nodes (Organization Level) */}
              <div className="space-y-6">
                {objectives
                  .filter((o) => o.level === 'Organization')
                  .map((orgObj) => (
                    <div key={orgObj.id} className="border border-emerald-200 rounded-2xl p-5 bg-emerald-50/20">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded bg-emerald-600 text-white text-xs font-bold">
                            Organization
                          </span>
                          <h3 className="font-bold text-sm text-slate-900">{orgObj.title}</h3>
                        </div>
                        <ProgressBar
                          progress={orgObj.progress || 0}
                          expectedProgress={cycleExpectedPace}
                          showLabels
                          className="w-48"
                        />
                      </div>

                      {/* Child Department Objectives */}
                      <div className="pl-6 border-l-2 border-emerald-300 space-y-4 mt-4">
                        {objectives
                          .filter((d) => d.parentObjectiveId === orgObj.id)
                          .map((deptObj) => (
                            <div key={deptObj.id} className="border border-sky-200 rounded-xl p-4 bg-sky-50/20">
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <span className="px-2 py-0.5 rounded bg-[#2d8fd8] text-white text-xs font-bold">
                                    Department
                                  </span>
                                  <h4 className="font-bold text-sm text-slate-900">{deptObj.title}</h4>
                                </div>
                                <ProgressBar
                                  progress={deptObj.progress || 0}
                                  expectedProgress={cycleExpectedPace}
                                  showLabels
                                  className="w-44"
                                />
                              </div>

                              {/* Child Team Objectives */}
                              <div className="pl-6 border-l-2 border-sky-300 space-y-3 mt-3">
                                {objectives
                                  .filter((t) => t.parentObjectiveId === deptObj.id)
                                  .map((teamObj) => (
                                    <div key={teamObj.id} className="border border-purple-200 rounded-xl p-3 bg-purple-50/20">
                                      <div className="flex items-center justify-between mb-2">
                                        <div className="flex items-center gap-2">
                                          <span className="px-2 py-0.5 rounded bg-purple-600 text-white text-xs font-bold">
                                            Team
                                          </span>
                                          <h5 className="font-bold text-xs text-slate-900">{teamObj.title}</h5>
                                        </div>
                                        <ProgressBar
                                          progress={teamObj.progress || 0}
                                          expectedProgress={cycleExpectedPace}
                                          showLabels
                                          className="w-40"
                                        />
                                      </div>

                                      {/* Child Individual Objectives */}
                                      <div className="pl-6 border-l-2 border-purple-300 space-y-2 mt-2">
                                        {objectives
                                          .filter((ind) => ind.parentObjectiveId === teamObj.id)
                                          .map((indObj) => (
                                            <div
                                              key={indObj.id}
                                              onClick={() => navigate(`/okrs/${indObj.id}`)}
                                              className="border border-slate-200 rounded-lg p-2.5 bg-white hover:border-[#2d8fd8] cursor-pointer flex items-center justify-between text-xs"
                                            >
                                              <div className="flex items-center gap-2">
                                                <span className="px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-semibold text-[10px]">
                                                  Individual
                                                </span>
                                                <span className="font-semibold text-slate-800">{indObj.title}</span>
                                                <ObjectiveStatusPill status={indObj.status} />
                                              </div>
                                              <ProgressBar
                                                progress={indObj.progress || 0}
                                                expectedProgress={cycleExpectedPace}
                                                showLabels
                                                className="w-36"
                                              />
                                            </div>
                                          ))}
                                      </div>
                                    </div>
                                  ))}
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Cancel Confirm Dialog */}
      <ConfirmDialog
        isOpen={cancelTargetId !== null}
        onClose={() => setCancelTargetId(null)}
        onConfirm={handleCancelConfirm}
        title="Cancel and Archive Objective?"
        message="This action will mark the objective as Cancelled and move it to Archived status."
        confirmLabel="Cancel Objective"
        isDestructive
      />
    </div>
  );
};
