import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Kanban, Target, TrendingUp, AlertTriangle } from 'lucide-react';
import { useAuthStore } from '../auth/authStore';
import { getObjectives } from '../../api';
import { getDb } from '../../api/mockDb';
import { Objective, KeyResult } from '../../types';
import {
  ObjectiveStatusPill,
  ObjectiveHealthChip,
  KRStatusChip,
  ApprovalChip,
} from '../../components/ui/Chips';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { calculateExpectedProgress } from '../../lib/calculations';

export const OkrStatusBoardPage: React.FC = () => {
  const { currentUser, selectedCycleId } = useAuthStore();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'objectives' | 'krs'>('objectives');
  const [objectives, setObjectives] = useState<Objective[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const db = getDb();
  const currentCycle = db.cycles.find((c) => c.id === selectedCycleId) || db.cycles[1];
  const asOfDate = db.devSettings.demoDate;
  const cycleExpectedPace = calculateExpectedProgress(currentCycle.startDate, currentCycle.endDate, asOfDate);

  useEffect(() => {
    setIsLoading(true);
    getObjectives({
      cycleId: selectedCycleId,
      ownerId: currentUser?.role === 'EMPLOYEE' ? currentUser.id : undefined,
    }).then((data) => {
      setObjectives(data);
      setIsLoading(false);
    });
  }, [selectedCycleId, currentUser]);

  const allKRs = db.keyResults.filter((kr) =>
    objectives.some((o) => o.id === kr.objectiveId)
  );

  // Objectives Columns (Section 11.8)
  const objColumns = [
    {
      id: 'draft',
      title: 'Draft',
      items: objectives.filter((o) => o.status === 'Draft'),
      color: 'border-slate-300 bg-slate-50/50',
    },
    {
      id: 'active-ontrack',
      title: 'Active · On Track',
      items: objectives.filter((o) => o.status === 'Active' && o.health === 'On Track'),
      color: 'border-emerald-300 bg-emerald-50/30',
    },
    {
      id: 'active-atrisk',
      title: 'Active · At Risk',
      items: objectives.filter((o) => o.status === 'Active' && o.health === 'At Risk'),
      color: 'border-amber-300 bg-amber-50/30',
    },
    {
      id: 'active-introuble',
      title: 'Active · In Trouble',
      items: objectives.filter((o) => o.status === 'Active' && o.health === 'In Trouble'),
      color: 'border-red-300 bg-red-50/30',
    },
    {
      id: 'completed',
      title: 'Completed',
      items: objectives.filter((o) => o.status === 'Completed'),
      color: 'border-blue-300 bg-blue-50/30',
    },
    {
      id: 'archived',
      title: 'Archived',
      items: objectives.filter((o) => o.status === 'Archived'),
      color: 'border-slate-400 bg-slate-100/40',
    },
  ];

  // Key Results Columns (Section 11.8)
  const krColumns = [
    {
      id: 'kr-ontrack',
      title: 'On Track',
      items: allKRs.filter((k) => k.status === 'On Track'),
      color: 'border-emerald-300 bg-emerald-50/30',
    },
    {
      id: 'kr-atrisk',
      title: 'At Risk',
      items: allKRs.filter((k) => k.status === 'At Risk'),
      color: 'border-amber-300 bg-amber-50/30',
    },
    {
      id: 'kr-introuble',
      title: 'In Trouble',
      items: allKRs.filter((k) => k.status === 'In Trouble'),
      color: 'border-red-300 bg-red-50/30',
    },
    {
      id: 'kr-completed',
      title: 'Completed',
      items: allKRs.filter((k) => k.status === 'Completed'),
      color: 'border-blue-300 bg-blue-50/30',
    },
  ];

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1e293b]">OKR Status & Progress Board</h1>
          <p className="text-xs text-[#64748b] mt-1">
            Categorized board columns based on active health, pace gap, and completion.
          </p>
        </div>

        {/* Mode Toggle */}
        <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 self-start">
          <button
            onClick={() => setMode('objectives')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              mode === 'objectives'
                ? 'bg-white shadow text-[#2d8fd8]'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Objectives View
          </button>
          <button
            onClick={() => setMode('krs')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              mode === 'krs' ? 'bg-white shadow text-[#2d8fd8]' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Key Results View
          </button>
        </div>
      </div>

      {/* OBJECTIVES MODE */}
      {mode === 'objectives' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 items-start">
          {objColumns.map((col) => (
            <div
              key={col.id}
              className={`rounded-2xl border ${col.color} p-3.5 flex flex-col gap-3 min-h-[400px] shadow-sm`}
            >
              <div className="flex items-center justify-between pb-2 border-b border-black/5">
                <span className="font-bold text-xs text-slate-800">{col.title}</span>
                <span className="px-2 py-0.5 rounded-full bg-white text-[10px] font-bold shadow-sm">
                  {col.items.length}
                </span>
              </div>

              <div className="space-y-2.5">
                {col.items.map((obj) => {
                  const owner = db.users.find((u) => u.id === obj.ownerId);
                  const krsCount = db.keyResults.filter((k) => k.objectiveId === obj.id).length;

                  return (
                    <div
                      key={obj.id}
                      onClick={() => navigate(`/okrs/${obj.id}`)}
                      className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-sm hover:border-[#2d8fd8] cursor-pointer transition-all space-y-2"
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="font-semibold text-slate-500">[{obj.level}]</span>
                        <ApprovalChip state={obj.approvalState} />
                      </div>

                      <h4 className="font-bold text-xs text-slate-900 hover:text-[#2d8fd8] line-clamp-2">
                        {obj.title}
                      </h4>

                      <div className="text-[11px] text-slate-500 flex justify-between">
                        <span>{owner?.name}</span>
                        <span>{krsCount} KRs</span>
                      </div>

                      <ProgressBar
                        progress={obj.progress || 0}
                        expectedProgress={cycleExpectedPace}
                        showLabels
                      />
                    </div>
                  );
                })}

                {col.items.length === 0 && (
                  <div className="text-center py-8 text-[11px] text-slate-400">
                    No items
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* KEY RESULTS MODE */}
      {mode === 'krs' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
          {krColumns.map((col) => (
            <div
              key={col.id}
              className={`rounded-2xl border ${col.color} p-4 flex flex-col gap-3 min-h-[400px] shadow-sm`}
            >
              <div className="flex items-center justify-between pb-2 border-b border-black/5">
                <span className="font-bold text-xs text-slate-800">{col.title}</span>
                <span className="px-2 py-0.5 rounded-full bg-white text-[10px] font-bold shadow-sm">
                  {col.items.length}
                </span>
              </div>

              <div className="space-y-3">
                {col.items.map((kr) => {
                  const parent = db.objectives.find((o) => o.id === kr.objectiveId);
                  const owner = db.users.find((u) => u.id === kr.ownerId);

                  return (
                    <div
                      key={kr.id}
                      onClick={() => navigate(`/okrs/${kr.objectiveId}/krs/${kr.id}`)}
                      className="bg-white p-3.5 rounded-xl border border-slate-200/80 shadow-sm hover:border-[#2d8fd8] cursor-pointer transition-all space-y-2"
                    >
                      <div className="flex items-center justify-between text-[11px]">
                        <span className="text-slate-400 truncate max-w-[130px]">
                          {parent?.title}
                        </span>
                        <KRStatusChip
                          status={kr.status}
                          isDelayed={kr.isDelayed}
                          isOverridden={kr.statusOverridden}
                        />
                      </div>

                      <h4 className="font-bold text-xs text-slate-900 hover:text-[#2d8fd8]">
                        {kr.name}
                      </h4>

                      <div className="text-[11px] text-slate-500 flex justify-between">
                        <span>{owner?.name}</span>
                        <span>Weight: {kr.weightage}%</span>
                      </div>

                      <ProgressBar
                        progress={kr.achievementPercent}
                        expectedProgress={kr.expectedPercent}
                        showLabels
                      />
                    </div>
                  );
                })}

                {col.items.length === 0 && (
                  <div className="text-center py-8 text-[11px] text-slate-400">
                    No key results in this status
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
