import React, { useState, useEffect } from 'react';
import { Award, Star, CheckCircle2, FileText, User } from 'lucide-react';
import { useAuthStore } from '../auth/authStore';
import { getPerformanceReviewCycles, getEvaluations, getEvaluationCriteria, submitEvaluation } from '../../api';
import { getDb } from '../../api/mockDb';
import { PerformanceEvaluation, EvaluationCriteria } from '../../types';
import { Button } from '../../components/ui/Button';
import { Modal } from '../../components/ui/Modal';
import { useToastStore } from '../../components/ui/Toast';

export const ReviewsPage: React.FC = () => {
  const { currentUser } = useAuthStore();
  const { showToast } = useToastStore();
  const role = currentUser?.role || 'EMPLOYEE';

  const [evaluations, setEvaluations] = useState<PerformanceEvaluation[]>([]);
  const [criteria, setCriteria] = useState<EvaluationCriteria[]>([]);
  const [activeEval, setActiveEval] = useState<PerformanceEvaluation | null>(null);
  const [responses, setResponses] = useState<Record<number, { text: string; score: number; rating: number }>>({});
  const [isLoading, setIsLoading] = useState(true);

  const db = getDb();

  const loadData = () => {
    setIsLoading(true);
    Promise.all([
      getEvaluations(1, currentUser?.id),
      getEvaluationCriteria(),
    ]).then(([evals, crit]) => {
      setEvaluations(evals);
      setCriteria(crit);
      setIsLoading(false);
    });
  };

  useEffect(() => {
    loadData();
  }, [currentUser]);

  const openEvaluation = (evaluation: PerformanceEvaluation) => {
    setActiveEval(evaluation);
    const respMap: Record<number, { text: string; score: number; rating: number }> = {};
    evaluation.responses.forEach((r) => {
      respMap[r.criteriaId] = {
        text: r.responseText,
        score: r.score,
        rating: r.rating,
      };
    });
    setResponses(respMap);
  };

  const handleSubmitEvaluation = async () => {
    if (!activeEval) return;

    const formattedResponses = criteria.map((c) => ({
      criteriaId: c.id,
      criteriaName: c.name,
      responseText: responses[c.id]?.text || 'No response recorded',
      score: responses[c.id]?.score || 80,
      rating: responses[c.id]?.rating || 4,
    }));

    try {
      await submitEvaluation(
        {
          ...activeEval,
          responses: formattedResponses,
        },
        currentUser?.id || 1
      );
      showToast({ type: 'success', message: 'Evaluation submitted successfully' });
      setActiveEval(null);
      loadData();
    } catch (err: any) {
      showToast({ type: 'error', message: err.message });
    }
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1e293b]">Performance Reviews & Evaluations</h1>
          <p className="text-xs text-[#64748b] mt-1">
            Formal evaluation cycle (Self, Manager, and Final evaluations) distinct from OKR tracking.
          </p>
        </div>
      </div>

      {/* Evaluations Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-[#f8f9fe] text-slate-700 font-semibold border-b">
                <th className="py-3 px-4">Evaluation Type</th>
                <th className="py-3 px-3">Subject Employee</th>
                <th className="py-3 px-3">Evaluator</th>
                <th className="py-3 px-3">Overall Score</th>
                <th className="py-3 px-3">Overall Rating</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {evaluations.map((ev) => {
                const emp = db.users.find((u) => u.id === ev.employeeId);
                const evaluator = db.users.find((u) => u.id === ev.evaluatorId);

                return (
                  <tr key={ev.id} className="hover:bg-slate-50">
                    <td className="py-3 px-4 font-bold text-slate-800">
                      {ev.evalType === 'SELF'
                        ? 'Self Evaluation'
                        : ev.evalType === 'MANAGER'
                        ? 'Manager Evaluation'
                        : 'Final HR Evaluation'}
                    </td>
                    <td className="py-3 px-3">{emp?.name}</td>
                    <td className="py-3 px-3 text-slate-600">{evaluator?.name}</td>
                    <td className="py-3 px-3 font-bold text-slate-900">
                      {ev.overallScore ? `${ev.overallScore} / 100` : '—'}
                    </td>
                    <td className="py-3 px-3">
                      {ev.overallRating ? (
                        <div className="flex items-center gap-1 font-bold text-amber-600">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>{ev.overallRating}</span>
                        </div>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          ev.status === 'SUBMITTED'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {ev.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <Button size="sm" variant="secondary" onClick={() => openEvaluation(ev)}>
                        {ev.status === 'SUBMITTED' ? 'View Evaluation' : 'Complete Form'}
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Evaluation Modal Form */}
      {activeEval && (
        <Modal
          isOpen={Boolean(activeEval)}
          onClose={() => setActiveEval(null)}
          title={`Performance Evaluation Form (${activeEval.evalType})`}
          description="Evaluate employee performance against core competency criteria"
          maxWidth="xl"
          footer={
            <div className="flex justify-end gap-2 w-full">
              <Button variant="secondary" onClick={() => setActiveEval(null)}>
                Close
              </Button>
              {activeEval.status !== 'SUBMITTED' && (
                <Button variant="primary" onClick={handleSubmitEvaluation}>
                  Submit Evaluation
                </Button>
              )}
            </div>
          }
        >
          <div className="space-y-6">
            {criteria.map((c) => {
              const currentResp = responses[c.id] || { text: '', score: 80, rating: 4 };

              return (
                <div key={c.id} className="p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-bold text-sm text-slate-900">{c.name}</h3>
                      <p className="text-xs text-slate-500 mt-0.5">{c.description}</p>
                    </div>
                    <span className="text-[11px] font-semibold text-slate-500">Weight: {c.weightage}%</span>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-slate-700">Detailed Response</label>
                    <textarea
                      disabled={activeEval.status === 'SUBMITTED'}
                      value={currentResp.text}
                      onChange={(e) =>
                        setResponses({
                          ...responses,
                          [c.id]: { ...currentResp, text: e.target.value },
                        })
                      }
                      rows={2}
                      className="w-full p-2.5 rounded-lg border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-[#2d8fd8] disabled:bg-slate-100"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-600 font-medium">Score (0-100)</span>
                        <span className="font-bold text-slate-900">{currentResp.score}</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="100"
                        disabled={activeEval.status === 'SUBMITTED'}
                        value={currentResp.score}
                        onChange={(e) =>
                          setResponses({
                            ...responses,
                            [c.id]: { ...currentResp, score: Number(e.target.value) },
                          })
                        }
                        className="w-full"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-slate-600 font-medium">Rating (Stars)</span>
                        <span className="font-bold text-amber-600">{currentResp.rating} / 5</span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="5"
                        step="0.5"
                        disabled={activeEval.status === 'SUBMITTED'}
                        value={currentResp.rating}
                        onChange={(e) =>
                          setResponses({
                            ...responses,
                            [c.id]: { ...currentResp, rating: Number(e.target.value) },
                          })
                        }
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </Modal>
      )}
    </div>
  );
};
