import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, AlertTriangle, Target, ChevronRight, TrendingUp } from 'lucide-react';
import { useAuthStore } from '../auth/authStore';
import { getDb } from '../../api/mockDb';
import { User, Objective, KeyResult } from '../../types';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { Button } from '../../components/ui/Button';
import { calculateExpectedProgress } from '../../lib/calculations';

export const TeamOkrsPage: React.FC = () => {
  const { currentUser, selectedCycleId } = useAuthStore();
  const navigate = useNavigate();

  const db = getDb();
  const currentCycle = db.cycles.find((c) => c.id === selectedCycleId) || db.cycles[1];
  const asOfDate = db.devSettings.demoDate;
  const cycleExpectedPace = calculateExpectedProgress(currentCycle.startDate, currentCycle.endDate, asOfDate);

  // Direct reports of manager
  const directReports = db.users.filter((u) => u.managerId === currentUser?.id);
  const [selectedReportId, setSelectedReportId] = useState<number | null>(
    directReports.length > 0 ? directReports[0].id : null
  );

  const selectedReport = db.users.find((u) => u.id === selectedReportId);
  const reportObjectives = db.objectives.filter(
    (o) => o.ownerId === selectedReportId && o.cycleId === selectedCycleId
  );

  return (
    <div className="space-y-6 pb-16">
      {/* Header */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#1e293b]">Team OKRs & Performance</h1>
          <p className="text-xs text-[#64748b] mt-1">
            Track goal execution, check-ins, and pacing for your direct reports in {currentCycle.name}.
          </p>
        </div>
      </div>

      {/* Direct Reports Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {directReports.map((member) => {
          const objs = db.objectives.filter(
            (o) => o.ownerId === member.id && o.cycleId === selectedCycleId
          );
          const memberKRs = db.keyResults.filter((k) => objs.some((o) => o.id === k.objectiveId));
          const atRiskCount = memberKRs.filter(
            (k) => k.status === 'At Risk' || k.status === 'In Trouble'
          ).length;

          const activeObjs = objs.filter((o) => o.status === 'Active');
          const avgProg =
            activeObjs.length > 0
              ? Math.round(activeObjs.reduce((s, o) => s + (o.progress || 0), 0) / activeObjs.length)
              : 0;

          const isSelected = member.id === selectedReportId;

          return (
            <div
              key={member.id}
              onClick={() => setSelectedReportId(member.id)}
              className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                isSelected
                  ? 'border-[#2d8fd8] bg-sky-50/40 shadow-sm'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center justify-center">
                  {member.avatar || 'US'}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-900">{member.name}</h3>
                  <p className="text-[11px] text-slate-500">{member.title}</p>
                </div>
              </div>

              <div className="space-y-2">
                <ProgressBar
                  progress={avgProg}
                  expectedProgress={cycleExpectedPace}
                  showLabels
                />
                <div className="flex justify-between items-center text-[11px] text-slate-500 pt-1">
                  <span>{objs.length} Objectives</span>
                  {atRiskCount > 0 && (
                    <span className="text-red-600 font-semibold flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" /> {atRiskCount} At Risk
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Member's Objectives */}
      {selectedReport && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b pb-3">
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">
                {selectedReport.name}'s Objectives ({reportObjectives.length})
              </h2>
              <p className="text-xs text-slate-500">Read-only oversight view with comment capabilities</p>
            </div>
          </div>

          <div className="space-y-3">
            {reportObjectives.map((obj) => (
              <div
                key={obj.id}
                onClick={() => navigate(`/okrs/${obj.id}`)}
                className="p-4 rounded-xl border border-slate-200 hover:border-[#2d8fd8] cursor-pointer transition-all bg-slate-50/50 hover:bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                      {obj.level}
                    </span>
                    <h3 className="font-bold text-sm text-slate-900">{obj.title}</h3>
                  </div>
                  <div className="text-xs text-slate-500">Weightage: {obj.weightage}%</div>
                </div>

                <div className="w-48 self-end sm:self-center">
                  <ProgressBar
                    progress={obj.progress || 0}
                    expectedProgress={cycleExpectedPace}
                    showLabels
                  />
                </div>
              </div>
            ))}

            {reportObjectives.length === 0 && (
              <div className="text-center py-8 text-slate-400 text-xs">
                No objectives created by this employee for this cycle.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
