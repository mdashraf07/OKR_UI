import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import {
  Check,
  Plus,
  Trash2,
  Edit2,
  AlertTriangle,
  Lightbulb,
  Save,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  FileCode2,
  HelpCircle,
} from 'lucide-react';
import { useAuthStore } from '../auth/authStore';
import {
  createObjective,
  updateObjective,
  getObjectiveById,
  submitObjective,
} from '../../api';
import { getDb } from '../../api/mockDb';
import {
  Objective,
  KeyResult,
  ObjectiveLevel,
  Template,
} from '../../types';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Input';
import { Select } from '../../components/ui/Select';
import { KeyResultDrawer, KeyResultFormData } from '../key-result/KeyResultDrawer';
import { ObjectiveStatusPill, ApprovalChip } from '../../components/ui/Chips';
import { useToastStore } from '../../components/ui/Toast';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { validateKRWeightages } from '../../lib/calculations';

export const CreateObjectivePage: React.FC = () => {
  const { objectiveId } = useParams<{ objectiveId?: string }>();
  const [searchParams] = useSearchParams();
  const isEdit = Boolean(objectiveId);

  const { currentUser, selectedCycleId } = useAuthStore();
  const navigate = useNavigate();
  const { showToast } = useToastStore();

  const db = getDb();
  const currentCycle = db.cycles.find((c) => c.id === selectedCycleId) || db.cycles[1];

  // Wizard Step (1 to 4)
  const [step, setStep] = useState<number>(searchParams.get('template') ? 1 : 2);

  // Form State
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [ownerId, setOwnerId] = useState<number>(currentUser?.id || 1);
  const [level, setLevel] = useState<ObjectiveLevel>('Individual');
  const [departmentId, setDepartmentId] = useState<number>(currentUser?.departmentId || 1);
  const [startDate, setStartDate] = useState(currentCycle.startDate.slice(0, 10));
  const [endDate, setEndDate] = useState(currentCycle.endDate.slice(0, 10));
  const [weightage, setWeightage] = useState<number>(50);
  const [parentObjectiveId, setParentObjectiveId] = useState<number | undefined>(undefined);
  const [keyResults, setKeyResults] = useState<KeyResultFormData[]>([]);

  // Drawer & Dialog States
  const [isKRDrawerOpen, setIsKRDrawerOpen] = useState(false);
  const [editingKRIndex, setEditingKRIndex] = useState<number | null>(null);
  const [isSubmitConfirmOpen, setIsSubmitConfirmOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [lastSavedTime, setLastSavedTime] = useState<string>('Saved just now');

  // Load existing data if edit mode
  useEffect(() => {
    if (objectiveId) {
      getObjectiveById(Number(objectiveId)).then(({ objective, keyResults: krs }) => {
        setTitle(objective.title);
        setDescription(objective.description || '');
        setOwnerId(objective.ownerId);
        setLevel(objective.level);
        setDepartmentId(objective.departmentId || 1);
        setStartDate(objective.startDate.slice(0, 10));
        setEndDate(objective.endDate.slice(0, 10));
        setWeightage(objective.weightage);
        setParentObjectiveId(objective.parentObjectiveId);
        setKeyResults(
          krs.map((k) => ({
            id: k.id,
            name: k.name,
            description: k.description,
            ownerId: k.ownerId,
            measurementTypeId: k.measurementTypeId,
            direction: k.direction,
            baseline: k.baseline,
            target: k.target,
            current: k.current,
            weightage: k.weightage,
            startDate: k.startDate,
            targetDate: k.targetDate,
          }))
        );
      });
    }
  }, [objectiveId]);

  // Intelligent Helper: Similar Title Check (Feature 8 in Section 12)
  const similarObjective = title.trim().length > 5
    ? db.objectives.find(
        (o) =>
          o.ownerId === ownerId &&
          o.id !== Number(objectiveId) &&
          o.title.toLowerCase().includes(title.toLowerCase().slice(0, 10))
      )
    : null;

  // Intelligent Helper: Alignment Suggestion (Feature 7 in Section 12)
  const alignmentSuggestions = db.objectives.filter(
    (o) =>
      o.cycleId === selectedCycleId &&
      (level === 'Individual' ? o.level === 'Team' : level === 'Team' ? o.level === 'Department' : false) &&
      o.status === 'Active'
  );

  // KR Weightage Validation & Meter
  const krWeightageTotal = keyResults.reduce((sum, kr) => sum + (Number(kr.weightage) || 0), 0);
  const isWeightageValid = krWeightageTotal === 100;

  // Intelligent Helper: Weightage Helper Actions (Feature 5 in Section 12)
  const handleSplitEvenly = () => {
    if (keyResults.length === 0) return;
    const split = Math.floor(100 / keyResults.length);
    const remainder = 100 - split * keyResults.length;
    const updated = keyResults.map((kr, idx) => ({
      ...kr,
      weightage: idx === keyResults.length - 1 ? split + remainder : split,
    }));
    setKeyResults(updated);
    showToast({ type: 'info', message: 'Weightages split evenly across key results' });
  };

  const handlePutRemainderOnLast = () => {
    if (keyResults.length === 0) return;
    const currentSumWithoutLast = keyResults
      .slice(0, -1)
      .reduce((sum, kr) => sum + (Number(kr.weightage) || 0), 0);
    const remaining = Math.max(0, 100 - currentSumWithoutLast);
    const updated = [...keyResults];
    updated[updated.length - 1].weightage = remaining;
    setKeyResults(updated);
    showToast({ type: 'info', message: `Remainder of ${remaining}% assigned to last KR` });
  };

  // Template prefill (Step 1)
  const handleSelectTemplate = (template: Template) => {
    const objTemplate = template.objectives[0];
    if (objTemplate) {
      setTitle(objTemplate.title);
      setDescription(objTemplate.description);
      setLevel(objTemplate.level);
      setKeyResults(
        objTemplate.keyResults.map((kr) => ({
          name: kr.name,
          measurementTypeId: kr.measurementTypeId,
          direction: kr.direction,
          baseline: kr.baseline,
          target: kr.target,
          weightage: kr.weightage,
          ownerId,
          startDate: new Date(startDate).toISOString(),
          targetDate: new Date(endDate).toISOString(),
        }))
      );
      showToast({ type: 'success', message: `Template "${template.name}" applied` });
      setStep(2);
    }
  };

  // Add / Edit KR from Drawer
  const handleSaveKR = (krData: KeyResultFormData, andAddAnother?: boolean) => {
    if (editingKRIndex !== null) {
      const updated = [...keyResults];
      updated[editingKRIndex] = krData;
      setKeyResults(updated);
      setEditingKRIndex(null);
    } else {
      setKeyResults([...keyResults, krData]);
    }
    if (!andAddAnother) {
      setIsKRDrawerOpen(false);
    }
  };

  // Save Draft (autosave / explicit save)
  const handleSaveDraft = async () => {
    try {
      if (isEdit) {
        await updateObjective(
          Number(objectiveId),
          {
            title,
            description,
            level,
            departmentId,
            weightage,
            parentObjectiveId,
          },
          currentUser?.id || 1
        );
      } else {
        await createObjective(
          {
            cycleId: selectedCycleId,
            ownerId,
            level,
            departmentId,
            title: title || 'Draft Objective',
            description,
            startDate: new Date(startDate).toISOString(),
            endDate: new Date(endDate).toISOString(),
            weightage,
            parentObjectiveId,
            keyResults: keyResults.map((kr) => ({ ...kr, current: kr.current ?? 0 })),
          },
          currentUser?.id || 1
        );
      }
      setLastSavedTime('Saved just now');
      showToast({ type: 'success', message: 'Objective draft saved' });
      navigate('/okrs');
    } catch (err: any) {
      showToast({ type: 'error', message: err.message || 'Failed to save' });
    }
  };

  // Final Submit for Approval
  const handleSubmitForApproval = async () => {
    setIsSubmitting(true);
    try {
      let targetObjId = Number(objectiveId);
      if (!isEdit) {
        const created = await createObjective(
          {
            cycleId: selectedCycleId,
            ownerId,
            level,
            departmentId,
            title,
            description,
            startDate: new Date(startDate).toISOString(),
            endDate: new Date(endDate).toISOString(),
            weightage,
            parentObjectiveId,
            keyResults: keyResults.map((kr) => ({ ...kr, current: kr.current ?? 0 })),
          },
          currentUser?.id || 1
        );
        targetObjId = created.id;
      }

      await submitObjective(targetObjId, currentUser?.id || 1);
      setIsSubmitting(false);
      setIsSubmitConfirmOpen(false);
      showToast({ type: 'success', message: 'Submitted for Level 1 Manager Review' });
      navigate(`/okrs/${targetObjId}`);
    } catch (err: any) {
      setIsSubmitting(false);
      showToast({ type: 'error', message: err.message || 'Submission error' });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      {/* Top Banner & Autosave indicator */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[#1e293b]">
            {isEdit ? 'Edit Objective' : 'Create Objective'}
          </h1>
          <p className="text-xs text-[#64748b]">
            Cycle: {currentCycle.name} · Follows standard 2-stage HRMS approval
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span>{lastSavedTime}</span>
        </div>
      </div>

      {/* 4-Step Stepper Header */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex items-center justify-between">
        {[
          { num: 1, label: 'Start' },
          { num: 2, label: 'Details' },
          { num: 3, label: 'Key Results' },
          { num: 4, label: 'Review & Submit' },
        ].map((s) => (
          <div
            key={s.num}
            onClick={() => s.num < step && setStep(s.num)}
            className={`flex items-center gap-2 cursor-pointer ${
              step === s.num
                ? 'text-[#2d8fd8] font-bold'
                : step > s.num
                ? 'text-emerald-600 font-medium'
                : 'text-slate-400'
            }`}
          >
            <div
              className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                step === s.num
                  ? 'bg-[#2d8fd8] text-white shadow-sm'
                  : step > s.num
                  ? 'bg-emerald-100 text-emerald-700'
                  : 'bg-slate-100 text-slate-400'
              }`}
            >
              {step > s.num ? <Check className="w-4 h-4" /> : s.num}
            </div>
            <span className="text-xs hidden sm:inline">{s.label}</span>
          </div>
        ))}
      </div>

      {/* STEP 1: START (Blank or Template) */}
      {step === 1 && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
          <div>
            <h2 className="text-base font-bold text-[#1e293b]">How would you like to start?</h2>
            <p className="text-xs text-[#64748b] mt-1">
              Choose whether to define a blank goal or prefill from approved templates.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div
              onClick={() => setStep(2)}
              className="p-5 rounded-2xl border-2 border-slate-200 hover:border-[#2d8fd8] bg-slate-50/50 hover:bg-sky-50/30 cursor-pointer transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-sky-100 text-[#0284c7] flex items-center justify-center font-bold mb-3">
                  <Plus className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-sm text-slate-900">Blank Objective</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Start from scratch and configure custom key results, metrics, and weightages.
                </p>
              </div>
              <Button size="sm" variant="secondary" className="mt-4 self-start">
                Continue Blank
              </Button>
            </div>

            {/* Template Card */}
            {db.templates.map((tpl) => (
              <div
                key={tpl.id}
                onClick={() => handleSelectTemplate(tpl)}
                className="p-5 rounded-2xl border-2 border-slate-200 hover:border-emerald-500 bg-slate-50/50 hover:bg-emerald-50/30 cursor-pointer transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold mb-3">
                    <FileCode2 className="w-5 h-5" />
                  </div>
                  <h3 className="font-bold text-sm text-slate-900">{tpl.name}</h3>
                  <p className="text-xs text-slate-500 mt-1 line-clamp-2">{tpl.description}</p>
                </div>
                <Button size="sm" variant="primary" className="mt-4 self-start">
                  Use Template
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* STEP 2: DETAILS */}
      {step === 2 && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
          <div>
            <h2 className="text-base font-bold text-[#1e293b]">Objective Details</h2>
            <p className="text-xs text-[#64748b] mt-1">
              Define the goal statement, alignment parent, cycle dates, and weightage.
            </p>
          </div>

          {/* Similar Objective Warning Alert (Feature 8) */}
          {similarObjective && (
            <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-amber-800">
                <span className="font-bold">A similar objective already exists: </span>
                <span className="underline cursor-pointer" onClick={() => navigate(`/okrs/${similarObjective.id}`)}>
                  "{similarObjective.title}"
                </span>
                . Ensure this goal represents a distinct quarterly milestone.
              </div>
            </div>
          )}

          <div className="space-y-4">
            <Input
              label="Objective Name"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Close 3 enterprise deals"
              required
            />

            <div className="flex flex-col gap-1.5">
              <label className="text-[13px] font-medium text-[#374151]">Description (Optional)</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
                placeholder="Describe the context, target clients, and impact..."
                className="w-full p-3 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-[#2d8fd8]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Select
                label="Level"
                value={level}
                onChange={(e) => setLevel(e.target.value as ObjectiveLevel)}
                options={[
                  { value: 'Individual', label: 'Individual' },
                  { value: 'Team', label: 'Team' },
                  { value: 'Department', label: 'Department' },
                  { value: 'Organization', label: 'Organization' },
                ]}
              />

              <Select
                label="Department"
                value={departmentId}
                onChange={(e) => setDepartmentId(Number(e.target.value))}
                options={db.departments.map((d) => ({ value: d.id, label: d.name }))}
              />
            </div>

            {/* Alignment Parent Objective Picker */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-[13px] font-medium text-[#374151]">
                  Aligns to (Parent Objective)
                </label>
                {alignmentSuggestions.length > 0 && (
                  <span className="text-[11px] text-[#2d8fd8] flex items-center gap-1">
                    <Lightbulb className="w-3 h-3" />
                    Suggested: "{alignmentSuggestions[0].title}"
                  </span>
                )}
              </div>
              <Select
                value={parentObjectiveId || ''}
                onChange={(e) =>
                  setParentObjectiveId(e.target.value ? Number(e.target.value) : undefined)
                }
              >
                <option value="">No parent (Standalone / Top-level)</option>
                {db.objectives
                  .filter((o) => o.cycleId === selectedCycleId && o.id !== Number(objectiveId))
                  .map((o) => (
                    <option key={o.id} value={o.id}>
                      [{o.level}] {o.title}
                    </option>
                  ))}
              </Select>
            </div>

            {/* Dates & Weightage */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input
                label="Start Date"
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                required
              />

              <Input
                label="End Date"
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                required
              />

              <Input
                label="Objective Weightage (%)"
                type="number"
                min={0}
                max={100}
                value={weightage}
                onChange={(e) => setWeightage(Number(e.target.value))}
                required
              />
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t">
            <Button variant="secondary" onClick={() => setStep(1)}>
              Back
            </Button>
            <Button
              variant="primary"
              disabled={title.trim().length < 3}
              onClick={() => setStep(3)}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Next: Key Results
            </Button>
          </div>
        </div>
      )}

      {/* STEP 3: KEY RESULTS */}
      {step === 3 && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-[#1e293b]">Define Key Results</h2>
              <p className="text-xs text-[#64748b]">
                Add measurable outcomes. Sum of KR weightages must equal exactly 100.
              </p>
            </div>
            <Button
              size="sm"
              variant="primary"
              onClick={() => {
                setEditingKRIndex(null);
                setIsKRDrawerOpen(true);
              }}
              leftIcon={<Plus className="w-4 h-4" />}
            >
              Add Key Result
            </Button>
          </div>

          {/* Weightage Meter Bar (Section 11.3) */}
          <div
            className={`p-4 rounded-xl border flex flex-col sm:flex-row items-center justify-between gap-3 ${
              isWeightageValid
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : 'bg-amber-50 border-amber-200 text-amber-900'
            }`}
          >
            <div>
              <div className="text-xs font-bold uppercase tracking-wider">
                KR Weightages Meter: {krWeightageTotal} of 100
              </div>
              <div className="text-[11px] opacity-80 mt-0.5">
                {isWeightageValid
                  ? 'Weightage requirement satisfied (100%). Ready to submit.'
                  : `Remaining to allocate: ${100 - krWeightageTotal}%`}
              </div>
            </div>

            {/* Quick helper buttons */}
            {!isWeightageValid && keyResults.length > 0 && (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleSplitEvenly}
                  className="px-2.5 py-1 rounded bg-white text-xs font-semibold shadow-sm hover:bg-slate-50 border border-slate-200"
                >
                  Split evenly
                </button>
                <button
                  type="button"
                  onClick={handlePutRemainderOnLast}
                  className="px-2.5 py-1 rounded bg-white text-xs font-semibold shadow-sm hover:bg-slate-50 border border-slate-200"
                >
                  Put remainder on last KR
                </button>
              </div>
            )}
          </div>

          {/* Key Results Cards */}
          <div className="space-y-3">
            {keyResults.map((kr, index) => (
              <div
                key={index}
                className="p-4 rounded-xl border border-slate-200 hover:border-slate-300 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-500">KR #{index + 1}</span>
                    <h3 className="font-bold text-sm text-slate-900">{kr.name}</h3>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                    <span>Target: {kr.target}</span>
                    <span>·</span>
                    <span>Direction: {kr.direction}</span>
                    <span>·</span>
                    <span className="font-semibold text-slate-700">Weight: {kr.weightage}%</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  <button
                    onClick={() => {
                      setEditingKRIndex(index);
                      setIsKRDrawerOpen(true);
                    }}
                    className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-200"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      setKeyResults(keyResults.filter((_, i) => i !== index));
                    }}
                    className="p-1.5 rounded-lg text-red-500 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}

            {keyResults.length === 0 && (
              <div className="p-8 text-center border-2 border-dashed border-slate-200 rounded-xl text-xs text-slate-400">
                At least one Key Result is required before submission. Click "Add Key Result" above.
              </div>
            )}
          </div>

          <div className="flex justify-between pt-4 border-t">
            <Button variant="secondary" onClick={() => setStep(2)}>
              Back
            </Button>
            <Button
              variant="primary"
              disabled={keyResults.length === 0 || !isWeightageValid}
              onClick={() => setStep(4)}
              rightIcon={<ArrowRight className="w-4 h-4" />}
            >
              Next: Review & Submit
            </Button>
          </div>
        </div>
      )}

      {/* STEP 4: REVIEW & SUBMIT */}
      {step === 4 && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-sm space-y-6">
          <div>
            <h2 className="text-base font-bold text-[#1e293b]">Review Objective Summary</h2>
            <p className="text-xs text-[#64748b]">
              Verify details and approval chain route before submitting to managers.
            </p>
          </div>

          {/* Summary Card */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-200 text-slate-700">
                {level} Level
              </span>
              <ObjectiveStatusPill status="Draft" />
            </div>

            <h3 className="text-lg font-bold text-slate-900">{title}</h3>
            {description && <p className="text-xs text-slate-600">{description}</p>}

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-200/60 text-xs">
              <div>
                <span className="text-slate-400 block text-[11px]">Cycle</span>
                <span className="font-semibold text-slate-800">{currentCycle.name}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Weightage</span>
                <span className="font-semibold text-slate-800">{weightage}%</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Key Results</span>
                <span className="font-semibold text-slate-800">{keyResults.length} defined</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Approval State</span>
                <ApprovalChip state="NotSubmitted" />
              </div>
            </div>
          </div>

          {/* Approval Route Stepper Preview */}
          <div className="p-4 rounded-xl border border-sky-200 bg-sky-50/50 space-y-2">
            <div className="text-xs font-bold text-[#0369a1] uppercase tracking-wider">
              Governance Approval Path
            </div>
            <div className="flex items-center gap-3 text-xs text-slate-700">
              <span className="font-semibold">1. Employee Submit</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-semibold">2. Manager Review (Level 1)</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              <span className="font-semibold">3. HR/Admin Review (Level 2)</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-emerald-700 font-bold">Active</span>
            </div>
          </div>

          <div className="flex justify-between items-center pt-4 border-t">
            <Button variant="secondary" onClick={() => setStep(3)}>
              Back
            </Button>
            <div className="flex gap-2">
              <Button variant="secondary" onClick={handleSaveDraft} leftIcon={<Save className="w-4 h-4" />}>
                Save draft
              </Button>
              <Button
                variant="primary"
                onClick={() => setIsSubmitConfirmOpen(true)}
                isLoading={isSubmitting}
              >
                Submit for approval
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* KR Drawer */}
      <KeyResultDrawer
        isOpen={isKRDrawerOpen}
        onClose={() => setIsKRDrawerOpen(false)}
        onSave={handleSaveKR}
        initialData={
          editingKRIndex !== null
            ? ({
                ...keyResults[editingKRIndex],
                id: keyResults[editingKRIndex].id || 0,
                objectiveId: Number(objectiveId) || 0,
                achievementPercent: 0,
                status: 'On Track',
                statusOverridden: false,
                createdBy: currentUser?.id || 1,
                createdAt: new Date().toISOString(),
              } as KeyResult)
            : null
        }
        objectiveDates={{ startDate, endDate }}
        defaultOwnerId={ownerId}
      />

      {/* Submit Confirmation Dialog */}
      <ConfirmDialog
        isOpen={isSubmitConfirmOpen}
        onClose={() => setIsSubmitConfirmOpen(false)}
        onConfirm={handleSubmitForApproval}
        title="Submit Objective for Approval?"
        message="After submitting you cannot edit until a decision is made by your Manager and HR. Proceed to submit for review?"
        confirmLabel="Submit for approval"
        isLoading={isSubmitting}
      />
    </div>
  );
};
