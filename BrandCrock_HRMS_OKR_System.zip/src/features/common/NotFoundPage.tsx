export { NotFoundPage } from './ForbiddenPage';
